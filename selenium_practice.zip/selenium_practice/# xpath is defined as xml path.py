# xpath is defined as xml path 

# it is a syntax or language for findong any element on the web page using xml path expression
# it is used to find location of any element on a webpage using HTML DOM structure
# xpath can be used to navigate through elements and attributes in DOM
# it is adress of element.
# full xpath
# /html/body/div[1]/div[1]/div[1]/div/div/div/div[2]/div/div[1]/form/div[1]/div[1]/input
# relative xpath
#   //*[@id="email"]

# absolute xpath start from root node of html IT START WITH /
# relative xpath directly jump to element to DOM IT START WITH //

# HOW TO WRITE X PATH MANUALLLY RELATIVE 
# SyntaxError
# //tagname[@attribute = 'value']





