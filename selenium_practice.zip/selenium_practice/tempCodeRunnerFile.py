XPATH, "//input[@id = 'small-searchterms']")
element.send_keys("apple macbook pro")
